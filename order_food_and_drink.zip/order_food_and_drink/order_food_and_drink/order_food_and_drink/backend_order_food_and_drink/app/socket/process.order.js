module.exports = socketIo => {
    return socketIo;
};
