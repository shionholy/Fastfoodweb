module.exports = {
    SALT_ROUNDS: 10,
}