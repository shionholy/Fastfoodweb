module.exports = {
    accessTokenSecret: "Access_Token_Secret_order_food",
    accessTokenLife: "24h",
    refreshTokenSize: 100,
    refreshTokenLife: "5h",
    refreshTokenSecret: "Refresh_Token_Secret_order_food"
}