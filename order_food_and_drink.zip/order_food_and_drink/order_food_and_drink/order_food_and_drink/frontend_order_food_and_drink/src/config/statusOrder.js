export const statusOrder = {
    CANCELED: 'CANCELED',
    NEW: 'NEW',
    CONFIRMED: 'CONFIRMED',
    COMPLETED: 'COMPLETED',
    PROCESSING: 'PROCESSING'
}

// export default statusOrder;