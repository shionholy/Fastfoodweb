import React from 'react';

import './homeStaff.scss';

function Staff(props) {
    return (
        <div>
            <h2>Staff</h2>
        </div>
    );
}

export default Staff;