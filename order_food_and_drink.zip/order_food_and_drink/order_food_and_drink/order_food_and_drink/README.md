<<<<<<< HEAD
### Setup Project
```
make init
```

## Run Server
```
make run-server
```

## Run Client
```
make run-client
```

## Account
- Admin: 
user: admin@admin.ad
pass: 123456
- Staff:
user: staff@staff.st
pass: 123456
=======
# order_food_and_drink
>>>>>>> 2ca8a4c89f1baf8e5a84f3eb594bfc885412b98c
